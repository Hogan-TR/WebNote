console.info("chrome-ext template-react-ts content script");
